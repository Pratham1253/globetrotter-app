const express = require("express");
const router = express.Router();
const Result = require("../models/Result");

// @route   POST api/results
// @desc    Save quiz result
// @access  Public
router.post("/", async (req, res) => {
  const { score, totalQuestions } = req.body;

  try {
    const newResult = new Result({
      score,
      totalQuestions,
    });

    const result = await newResult.save();
    res.json(result);
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
});

// @route   GET api/results
// @desc    Get all results
// @access  Public (would be Private in production)
router.get("/", async (req, res) => {
  try {
    const results = await Result.find().sort({ date: -1 });
    res.json(results);
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
});

module.exports = router;
