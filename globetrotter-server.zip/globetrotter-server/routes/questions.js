const express = require("express");
const router = express.Router();
const Question = require("../models/Question");

// @route   GET api/questions
// @desc    Get all questions
// @access  Public
router.get("/", async (req, res) => {
  try {
    const questions = await Question.find();
    res.json(questions);
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
});

// @route   POST api/questions
// @desc    Add a new question
// @access  Public (would be Private in production)
router.post("/", async (req, res) => {
  const { clues, options, correctAnswer, funFact } = req.body;

  try {
    const newQuestion = new Question({
      clues,
      options,
      correctAnswer,
      funFact,
    });

    const question = await newQuestion.save();
    res.json(question);
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
});

module.exports = router;
